package com.iiitb.imageEffectApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriveProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
