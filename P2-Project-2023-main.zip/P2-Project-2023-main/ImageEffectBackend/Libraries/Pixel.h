#ifndef PIXEL_H
#define PIXEL_H

struct Pixel {
    int r, g, b;
};

#endif