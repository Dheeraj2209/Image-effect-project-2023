export interface LogModel {
    timestamp: string;
    filename: string;
    effectName: string;
    optionValues: string;
}